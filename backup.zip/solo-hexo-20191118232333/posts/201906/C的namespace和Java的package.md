title: C#的namespace和Java的package
date: '2019-06-28 03:55:39'
updated: '2019-06-28 03:55:39'
tags: [C#, Java]
permalink: /articles/2019/06/28/1569338005723.html
---
# C#的namespace和Java的package

## Java中的package

在java中我们一般谈到package都知道这是java的包机，在java中为了方便类和类之间的管理我们引入了package用来解决这个问题，例如

```java
package com.edu.test
public class A{
	public static void Test();
}
```

在另一个包中的另一个类中我们要想访问类A我们需要借助```import```关键字

```java
import com.edu.test.A
public class B{
	public void Test2(){
		A.Test();
	}
}
```

当然为了访问其他包中的类我们需要```public```关键字，同样的为了直接调用方法我们需要关键字```static```声明静态方法。

### Java包的作用

- 1、把功能相似或相关的类或接口组织在同一个包中，方便类的查找和使用。
- 2、如同文件夹一样，包也采用了树形目录的存储方式。同一个包中的类名字是不同的，不同的包中的类的名字是可以相同的，当同时调用两个不同包中相同类名的类时，应该加上包名加以区别。因此，包可以避免名字冲突。
- 3、包也限定了访问权限，拥有包访问权限的类才能访问某个包中的类。



**创建包时需要注意如下几点：**

（1）创建包时用package关键字；

（2）如果有包声明，包声明一定作为源代码的第一行；

（3）包的名称一般为小写，包名要有意义。例如：数学计算包名可以命名“math”，再如，绘图包可以命名“drawing”；



## C#中的namespace

### 声明一个namespace(命名空间)

```c#
namespace myApp
{
  public class Program
  {
    public static void Test()
  }
}
```

如上所示这样我们就可以在C#中声明一个命名空间



### Java的package和C#的namespace的最大区别

- namespace是可以嵌套的

```c#
namespace A
{
  namespace B
  {
    namespace C
    {
      
    }
  }
}
```



**测试**

- 新建一个文件Program.cs

```c#
using System;

namespace myApp
{
    namespace Test{
        class Program2
        {
            public static void Test1()
            {
                Console.WriteLine("This is namespace Test, Class Program2, Method Test1");
            }
        }
    }
    public class Program
    {   
        public static void Test3()
        {
            Console.WriteLine("Now using namespace myApp Class Program");
        }
    }
}

```

**如上所示我们有两个命名空间分别是myApp和Test**

- 新建一个文件Program2.cs

```c#
using myApp;
using System;

namespace myApp2
{
    class Program3
    {
        public static void Test2()
        {
            Program.Test3();
        }
        
        public static void Test3()
        {
            myApp.Test.Program2.Test1();
        }

        static void Main(String[] args)
        {
            Test2();
            Test3();
        }
    }
}

```

**和java一样我们需要导入我们的命名空间这里我们使用```using```关键字 例如:```using myApp```**

- 这里新建了一个命名空间**myApp2**
- 新建了两个方法**Test2**、**Test3**
- **Test2**方法调用**myApp**命名空间中的**Program**类
- **Test3**方法调用**myApp**命名空间的子命名空间**Test**中的**Program1**类的**Test1**方法

**输出**

```bash
已加载“/usr/local/share/dotnet/shared/Microsoft.NETCore.App/2.2.5/System.Private.CoreLib.dll”。已跳过加载符号。模块进行了优化，并且调试器选项“仅我的代码”已启用。
已加载“/Users/rex/Desktop/Code/dotnet/myApp/bin/Debug/netcoreapp2.2/myApp.dll”。已加载符号。
已加载“/usr/local/share/dotnet/shared/Microsoft.NETCore.App/2.2.5/System.Runtime.dll”。模块已生成，不包含符号。
已加载“/usr/local/share/dotnet/shared/Microsoft.NETCore.App/2.2.5/System.Console.dll”。已跳过加载符号。模块进行了优化，并且调试器选项“仅我的代码”已启用。
已加载“/usr/local/share/dotnet/shared/Microsoft.NETCore.App/2.2.5/System.Threading.dll”。模块已生成，不包含符号。
已加载“/usr/local/share/dotnet/shared/Microsoft.NETCore.App/2.2.5/System.Runtime.Extensions.dll”。模块已生成，不包含符号。
Now using namespace myApp Class Program
This is namespace Test, Class Program2, Method Test1
程序“[41008] myApp.dll”已退出，代码为 0 (0x0)。
```



**如上所示我们已经完成的调用**



## 总结

- Java的package和C#的namespace都是为了更方便的管理类
- C#的namespace支持子namespace