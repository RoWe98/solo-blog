title: 修改百度开放平台人脸识别错误[Python]json 错误xx is not JSON serializable
date: '2019-09-24 23:13:22'
updated: '2019-09-24 23:13:22'
tags: [Note]
permalink: /articles/2019/09/24/1569338002136.html
---
# 修改百度开放平台人脸识别错误[Python]json 错误xx is not JSON serializable



# 简介

百度AI开放平台所用到的人脸识别功能，人体识别功能很多人特别喜欢用，但是！会遇到如下的错误：


    [Python]json 错误xx is not JSON serializable
    
那么如何解决这个问题呢？

很简单，如下所示：

首先打开你的terminal;windows的同学打开你的powershell或者cmd

如下所示 输入：
```bash
    pip3 show baidu-aip
    或
    pip show baidu-aip
```   

![avatar](https://s2.ax1x.com/2019/05/14/EohCfU.md.jpg)



找到location的位置进入该位置

然后进入site-packages位置后输入：

    cd aip
    ls
    
如下所示：

![avatar](https://s2.ax1x.com/2019/05/14/EohpkV.jpg)

找到face.py 文件 用vim打开

    vim face.py
    
在文本结尾输入如下代码


```python
class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, bytes):
            return str(obj, encoding='utf-8')
        return json.JSONEncoder.default(self, obj)
```


然后找到其中的 所有每个方法 例如match方法 在json.dump()那一行改为如下所示

![avatar](https://s2.ax1x.com/2019/05/14/EohNAP.md.jpg)

在False后加入如下代码
    
    cls = MyEncoder
    
注意空格

注意：建议将face.py中的所有方法的json.dump()中都改为如上所示的内容，防止bug再次出现


# END