title: 为黑苹果解锁AirDrop功能和蓝牙以及WI-FI
date: '2019-06-15 04:51:39'
updated: '2019-06-15 04:51:39'
tags: [黑苹果]
permalink: /articles/2019/06/15/1569338006698.html
---
# 为黑苹果解锁AirDrop功能和蓝牙以及WI-FI

## 写在前面

笔者的黑苹果安装在ThinkPad T450上由于网卡是因特尔的网卡 在黑苹果下面不支持WiFi和蓝牙，于是就想重新安装个网卡，网卡如图所示：

[![](https://s2.ax1x.com/2019/06/14/V56Y38.md.jpg)](https://imgchr.com/i/V56Y38)



网卡为NGFF接口的



## 解决方案

在网上搜索之后发现博通的网卡可以免驱 最巧的是macbook 自带的网卡就是**博通**的网卡，于是我在某宝上购买了一款型号为**BCM94360CS2**的博通网卡

[![](https://s2.ax1x.com/2019/06/14/V56tgS.md.jpg)](https://imgchr.com/i/V56tgS)



这款网卡正好佩戴一个转接卡可以让我们安装到主板的网卡接口上



## 安装

**打开笔记本的后盖找到安装网卡的位置 拆下我们之前的intel的网卡 安装上我们博通的网卡，然后插好天线**

安装完成就像这样

[![](https://s2.ax1x.com/2019/06/14/V56J9f.md.jpg)](https://imgchr.com/i/V56J9f)



## 测试

由于我们安装的macbook原装的网卡，所以按道理上我们的网卡在黑苹果上面蓝牙和WIFi都是免驱的



如图所示 我们电脑的WiFi 蓝牙 都可以**正常**使用

当然最重要的是**AirDrop** 完美使用！！



**Finder界面**

[![](https://s2.ax1x.com/2019/06/14/V56Z9K.md.png)](https://imgchr.com/i/V56Z9K)



**接受手机给电脑的AirDrop**

![](https://s2.ax1x.com/2019/06/14/V56KnH.png)



**手机给电脑发送**

[![](https://s2.ax1x.com/2019/06/14/V56Njg.md.png)](https://imgchr.com/i/V56Njg)



## End