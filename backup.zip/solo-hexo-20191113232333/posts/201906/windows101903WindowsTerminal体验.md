title: windows10 1903 + Windows Terminal 体验
date: '2019-06-01 04:23:00'
updated: '2019-06-01 04:23:00'
tags: [WindowsTerminal]
permalink: /articles/2019/06/01/1569338009257.html
---
# windows10 1903 + Windows Terminal 体验

## windows10 1903 安装

系统安装这里就不过多赘述了，在msdn上下载win10 1903 customer 版，这个版本包括家庭版，教育版，专业版等win10版本，这里我选择了win10专业版。

![安装](https://s2.ax1x.com/2019/05/30/VQFyk9.md.png)



安装由于我是mac的系统，这里也懒得装双系统所以就索性直接把系统装在我的虚拟机里面



经过一段时间1903安装完毕

[![Vlb8iD.md.png](https://s2.ax1x.com/2019/05/31/Vlb8iD.md.png)](https://imgchr.com/i/Vlb8iD)



## 安装宇宙第一IDE Visual Studio 2019

这里安装vs2019是为了等会方便我们编译项目

[![VlyIjH.md.png](https://s2.ax1x.com/2019/05/31/VlyIjH.md.png)](https://imgchr.com/i/VlyIjH)



- 具体安装的选项如图所示 安装完毕大概17G（不愧是宇宙第一IDE，真TM大！！！）

[![VlOoY8.md.png](https://s2.ax1x.com/2019/05/31/VlOoY8.md.png)](https://imgchr.com/i/VlOoY8)



- 然后等待安装即可



## 编译项目



### 1.在github上clone项目

```bash
git clone https://github.com/microsoft/Terminal
```

### 2. 打开clone的仓库输入

```bash
git submodule update --init --recursive
dep\nuget\nuget.exe restore OpenConsole.sln
```

### 3.打开宇宙第一IDE Visual Studio开始编译

[![VlbBo8.md.png](https://s2.ax1x.com/2019/05/31/VlbBo8.md.png)](https://imgchr.com/i/VlbBo8)



- 编译

![VlolC9.png](https://s2.ax1x.com/2019/05/31/VlolC9.png)



## Windows Terminal 体验

### 1.安装ubuntu子系统(WSL)

[![VlbrFS.md.png](https://s2.ax1x.com/2019/05/31/VlbrFS.md.png)](https://imgchr.com/i/VlbrFS)



### 2.打开Windows Terminal 

- 这里给大家放几张图片看看

[![VlLRaV.md.png](https://s2.ax1x.com/2019/05/31/VlLRaV.md.png)](https://imgchr.com/i/VlLRaV)



[![VlLhPU.md.png](https://s2.ax1x.com/2019/05/31/VlLhPU.md.png)](https://imgchr.com/i/VlLhPU)





[![VlLLa6.md.png](https://s2.ax1x.com/2019/05/31/VlLLa6.md.png)](https://imgchr.com/i/VlLLa6)



- 美化设置；这里附上我的设置文件

```json
{
  "alwaysShowTabs": true,
  "defaultProfile": "{81d66518-899b-471f-a02e-de60a762bf41}",
  "experimental_showTabsInTitlebar": true,
  "initialCols": 120,
  "initialRows": 30,
  "profiles": [
    {
      "guid": "{81d66518-899b-471f-a02e-de60a762bf41}",
      "name": "cmd",
      "colorscheme": "Campbell",
      "historySize": 9001,
      "snapOnInput": true,
      "cursorColor": "#FFFFFF",
      "cursorShape": "bar",
      "commandline": "cmd.exe",
      "fontFace": "Consolas",
      "fontSize": 12,
      "acrylicOpacity": 0.75,
      "useAcrylic": true,
      "closeOnExit": false,
      "padding": "0, 0, 0, 0"
    },
    {
      "guid": "{f5a53144-ba97-4c0d-9848-9fe4728837ed}",
      "name": "PowerShell",
      "colorscheme": "Campbell",
      "historySize": 9001,
      "snapOnInput": true,
      "cursorColor": "#FFFFFF",
      "cursorShape": "bar",
      "commandline": "powershell.exe",
      "fontFace": "Courier New",
      "fontSize": 12,
      "acrylicOpacity": 0.5,
      "useAcrylic": true,
      "closeOnExit": false,
      "padding": "0, 0, 0, 0"
    },
    {
      "guid": "{09dc5eef-6840-4050-ae69-21e55e6a2e62}",
      "name": "Ubuntu",
      "colorscheme": "Campbell",
      "historySize": 9001,
      "snapOnInput": true,
      "cursorColor": "#FFFFFF",
      "cursorShape": "bar",
      "commandline": "wsl.exe",
      "fontFace": "Consolas",
      "fontSize": 12,
      "acrylicOpacity": 0.75,
      "useAcrylic": true,
      "closeOnExit": false,
      "padding": "0, 0, 0, 0"
    }
  ],
  "schemes": [
    {
      "name": "Campbell",
      "foreground": "#F2F2F2",
      "background": "#0C0C0C",
      "colors": [ "#0C0C0C", "#C50F1F", "#13A10E", "#C19C00", "#0037DA", "#881798", "#3A96DD", "#CCCCCC", "#767676", "#E74856", "#16C60C", "#F9F1A5", "#3B78FF", "#B4009E", "#61D6D6", "#F2F2F2" ]
    },
    {
      "name": "Solarized Dark",
      "foreground": "#FDF6E3",
      "background": "#073642",
      "colors": [ "#073642", "#D30102", "#859900", "#B58900", "#268BD2", "#D33682", "#2AA198", "#EEE8D5", "#002B36", "#CB4B16", "#586E75", "#657B83", "#839496", "#6C71C4", "#93A1A1", "#FDF6E3" ]
    },
    {
      "name": "Solarized Light",
      "foreground": "#073642",
      "background": "#FDF6E3",
      "colors": [ "#073642", "#D30102", "#859900", "#B58900", "#268BD2", "#D33682", "#2AA198", "#EEE8D5", "#002B36", "#CB4B16", "#586E75", "#657B83", "#839496", "#6C71C4", "#93A1A1", "#FDF6E3" ]
    }
  ],
  "showTerminalTitleInTitlebar": false
}
```





## 总结



目前Windows Terminal 还没有正式发布 还在测试阶段 肯定会有多多少少一些bug，但是喜欢尝鲜的朋友可以试试毕竟这也算是微软的一次很大的创新



## 附录

- 编译详细教程

[教程](https://www.jianshu.com/p/dfcd4769be71)