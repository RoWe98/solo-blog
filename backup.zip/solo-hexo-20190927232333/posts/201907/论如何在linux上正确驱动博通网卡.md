title: 论如何在linux上正确驱动博通网卡
date: '2019-07-19 20:42:28'
updated: '2019-07-19 20:42:28'
tags: [Linux]
permalink: /articles/2019/07/19/1569338012252.html
---
# 论如何在linux上正确驱动博通网卡

## 写在前面

我的网卡型号是BCM94360，前几天安装了基于Arch Linux的Linux发行版Manjaro出现了无法识别无线网卡驱动的问题

```bash
➜  ~ lspci | grep -i net            
00:19.0 Ethernet controller: Intel Corporation Ethernet Connection (3) I218-LM (rev 03)
03:00.0 Network controller: Broadcom Inc. and subsidiaries BCM4360 802.11ac Wireless Network Adapter (rev 03)
```

如上所示，在命令行输入```lspci | grep -i net```后可以查看自己的无线网卡的型号，我的型号为**BCM4360**

**问题描述**

- 找不到无线网络
- 找不到无线开关




## 解决

在我通过bing，baidu，google后找到了基本的解决思路，是因为没有安装对应的网卡驱动

**安装驱动**

**1.更新系统软件**
```sudo pacman -Syu```

**2.安装对应的linux-headers**

- 在设置中找到自己系统版本对应的内核
![](https://s2.ax1x.com/2019/07/19/ZvKNIe.png)
如上所示我的内核版本为```Linux 4.19.59-1```

- ```sudo pacman -S linux-headers```
这里选择对应上面的```Linux 4.19.59-1```版本的即可

- 安装博通网卡驱动```sudo pacman -S broadcom-wl-dkms```

**3.重启**

**重启过后继续继续输入```dkms status```**

若显示如下则说明安装成功

```bash
➜  ~ dkms status                    
broadcom-wl, 6.30.223.271, 4.19.59-1-MANJARO, x86_64: installed
```

**到这大部分博通的网卡应该都可以解决wifi的问题**

## 但是

我出现了新的问题，搜索不到wifi

![](https://s2.ax1x.com/2019/07/19/ZvMCdO.jpg)

**WDNMD!!**

**解决方法**

淘宝买了一个linux免驱的无线网卡

![](https://s2.ax1x.com/2019/07/19/ZvMeyt.jpg)

**怎么说？ WDNMD！ 白给了！**

![](https://s2.ax1x.com/2019/07/19/ZvM3Wj.gif)