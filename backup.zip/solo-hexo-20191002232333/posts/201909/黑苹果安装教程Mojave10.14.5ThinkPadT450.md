title: 黑苹果安装教程 (Mojave 10.14.5) ThinkPad T450
date: '2019-09-24 22:53:44'
updated: '2019-09-24 22:53:44'
tags: [黑苹果]
permalink: /articles/2019/09/24/1569336824863.html
---
![](https://img.hacpai.com/bing/20180104.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


# 黑苹果安装教程 (Mojave 10.14.5)

## 记一次我的黑苹果安装教程，本教程适用于ThinkPad T450 傻瓜式教学


## 准备工作

### 准备工具

- U盘大于8G
- U盘大小不限做PE盘
- [etcher](https://www.balena.io/etcher/)
- EFI文件（每个机型不同）
- 系统镜像

###  下载镜像

[macOS Mojave 10.14.5 18F132 正式版 with Clover 4928原版镜像](https://blog.daliansky.net/macOS-Mojave-10.14.5-18F132-official-version-with-Clover-4928-original-image.html)

### 制作安装镜像

- 下载[etcher](https://www.balena.io/etcher/)

[![](https://s2.ax1x.com/2019/06/08/VDu5VI.md.png)](https://imgchr.com/i/VDu5VI)

- select image 选择镜像
- select drive 选择u盘
- flash 写入u盘



### 将提前准备好的EFI复制粘贴到USB安装盘的EFI分区下

#### 显示磁盘分区信息

打开终端输入：```diskutil list```

```bash
RexdeMacBook-Pro:~ rex$ diskutil list
   #:                       TYPE NAME                    SIZE       IDENTIFIER
   0:      GUID_partition_scheme                        +8.0 GB     disk4
   1:                        EFI EFI                     209.7 MB   disk4s1
   2:                  Apple_HFS Install macOS Mojave         7.7 GB     disk4s2

/dev/disk3 (disk image):
   #:                       TYPE NAME                    SIZE       IDENTIFIER
   0:      GUID_partition_scheme                        +7.0 GB     disk3
   1:                        EFI EFI                     209.7 MB   disk3s1
   2:                  Apple_HFS Install macOS Mojave    6.7 GB     disk3s2
```

 根据磁盘空间查看是哪个分区 找到 EFI字样 的u盘 和 我们打开的镜像

分别为 插入的u盘flash后的分区 ```GUID_partition_scheme                        +8.0 GB     disk4```

其efi分区为```EFI EFI                     209.7 MB   disk4s1```

同理我们提前打开的dmg镜像的EFI为```disk3s1```



分别挂载这两个EFI

```bash
sudo diskutil mount disk4s1
sudo diskutil mount disk3s1
```



这里如果你想用傻瓜安装方法的话把你打开的镜像里面的EFI分区文件复制粘贴到USB的EFI分区里

![](https://s2.ax1x.com/2019/06/08/VDKAsJ.png)

[![
](https://s2.ax1x.com/2019/06/08/VDKZZR.md.png)](https://imgchr.com/i/VDKZZR)

#### 把BOOT 和CLOVER 复制粘贴到USB的EFI分区里放在EFI文件夹里



#### ！！！！注意

####  这里的EFI是万能EFI是[黑果小兵](https://blog.daliansky.net/)大大编写的万能EFI不保证可以使用

#### 如果你想使用现成EFI 完美支持T450的EFI那么进入如下链接下载EFI替换[EFI](https://github.com/jsassu20/Lenovo-ThinkPad-T450-Mojave)

[![](https://s2.ax1x.com/2019/06/08/VDKMRO.png)](https://imgchr.com/i/VDKMRO)



这里的EFI是由[jsassu20](https://github.com/jsassu20)为我们调试好的EFI直接就可以替换使用！



### BIOS 设定

- 关闭Bios的安全启动
- 设置启动模式为EFI





## 安装MacOS

- 开机按F12 进入启动项选择选择U盘启动
- 进入Clover主菜单
- 选择```Boot OS X Install from install macOS Mojave```
- 开始引导macOS系统

![](https://s2.ax1x.com/2019/06/08/VDKaJf.png)



这个过程需要1-2分钟,耐心等待进入安装程序,出现语言选择界面

- 语言选择 选择简体中文

[![](https://s2.ax1x.com/2019/06/08/VDK5y4.md.png)](https://imgchr.com/i/VDK5y4)

出现```macos实用工具``` 界面，选择磁盘工具



#### 磁盘工具

[![](https://s2.ax1x.com/2019/06/08/VDMZ6g.md.png)](https://imgchr.com/i/VDMZ6g)



选择```显示所有设备```

[![](https://s2.ax1x.com/2019/06/08/VDMlt0.md.png)](https://imgchr.com/i/VDMlt0)



选择`SSD Media`,点击`抹掉`按钮,选择默认的`Mac OS扩展(日志型)`,将名称修改为`Macintosh HD`,点击`抹掉`按钮

***假设您的磁盘是空的且数据是已经备份过的,别怪我没提醒你!!!***

[![](https://s2.ax1x.com/2019/06/08/VDM8pT.md.png)](https://imgchr.com/i/VDM8pT)



抹盘成功后,它会自动生成一个200MB的EFI分区,这样做的好处是不会出现安装过程中的由于EFI分区尺寸小于200MB而引起的无法安装的错误.当然前提是你的磁盘中没有重要的数据,或者您的数据已经提前备份过了.

[![](https://s2.ax1x.com/2019/06/08/VDMNnJ.md.png)](https://imgchr.com/i/VDMNnJ)

到这里,磁盘工具的动作就已经结束了.退出磁盘工具进入安装界面,进行系统的安装了.



####  安装

[![](https://s2.ax1x.com/2019/06/08/VDMwA1.md.png)](https://imgchr.com/i/VDMwA1)



- 进入安装界面
- 继续
- 同意
- 选择```Macintosh HD``` 安装

期间,它会把USB安装盘上的安装文件预复制到要安装的系统分区里,数据复制完后,它会自动重启

[![](https://s2.ax1x.com/2019/06/08/VDQAER.md.png)](https://imgchr.com/i/VDQAER)



然后进行第二阶段的安装

#### 安装第二阶段

第二阶段的安装会有两种界面,一种是不进安装界面直接安装,另一种是先进入安装界面直接安装,需要注意的是,无论是哪一种界面下,安装的过程中全程是禁用鼠标和键盘的,需要你做的只是耐心等待它安装完成

[![](https://s2.ax1x.com/2019/06/08/VDQeC6.md.png)](https://imgchr.com/i/VDQeC6)



安装速度取决于你的磁盘速度,第二阶段的安装已经与USB安装盘没什么关系了.macOS 10.14的安装完全区别于10.13,它不能免二次安装,甚至还需要重启多次,这些都是正常现象,请不要大惊小怪的.
系统安装完成后,重启进入系统设置向导



#### 设置向导

这里不需要多讲，自己设置等待完成就行。

### 将USB引导更换为磁盘引导

这个时候我默认认为你已经可以进入系统了

####由于我们之前启动一直使用的USB引导 我们也不可能永远插着U盘，所以这里我们需要把U盘上的EFI复制到系统盘 ```Macintosh HD``` 中



- 打开终端输入```diskutil list```
- 和之前把系统的EFI复制到U盘步骤一样找到你的系统盘的EFI分区和U盘的EFI分区分别挂载将U盘的EFI复制到硬盘中即可
- 如图所示

[![](https://s2.ax1x.com/2019/06/08/VDQs5q.md.png)](https://imgchr.com/i/VDQs5q)



如果不出什么意外你用的是刚才在github上下载的[EFI](https://github.com/jsassu20/Lenovo-ThinkPad-T450-Mojave)的话这个时候你应该是驱动都完美的



附上我的桌面电池、Wi-Fi、触摸板、声卡、网卡都是完美驱动

![](https://s2.ax1x.com/2019/06/08/VDQxZd.png)



#### 如果安装有问题，驱动有问题查看   [黑果小兵的教程](https://blog.daliansky.net/MacOS-installation-tutorial-XiaoMi-Pro-installation-process-records.html)



## 问题解决

### 1.USB3.0提示插入电源

删除EFI文件夹CLOVER文件夹KEXTS目录下的Other文件夹里面USBinject.kext

[![](https://s2.ax1x.com/2019/06/08/VDlrOe.md.png)](https://imgchr.com/i/VDlrOe)



### 2.没有我的机型的EFI

进入这个页面查找你的机型 [机型列表](https://github.com/daliansky/Hackintosh)

### 3.找不到镜像下载地址

进入页面[镜像下载](https://blog.daliansky.net/macOS-Mojave-10.14.5-18F132-official-version-with-Clover-4928-original-image.html)



## 写在最后

### 参考文档

- [macOS Mojave 10.14.5 18F132 正式版 with Clover 4928原版镜像](https://blog.daliansky.net/macOS-Mojave-10.14.5-18F132-official-version-with-Clover-4928-original-image.html)
- [macOS安装教程兼小米Pro安装过程记录](https://blog.daliansky.net/MacOS-installation-tutorial-XiaoMi-Pro-installation-process-records.html)
- [Hackintosh黑苹果长期维护机型EFI及安装教程整理](https://github.com/daliansky/Hackintosh)
- [**Lenovo-ThinkPad-T450-Mojave**](https://github.com/jsassu20/Lenovo-ThinkPad-T450-Mojave)
- [远景论坛]([http://bbs.pcbeta.com/forum-559-1.html](http://bbs.pcbeta.com/forum-559-1.html))
- [tonymacx86](https://www.tonymacx86.com/)


```
