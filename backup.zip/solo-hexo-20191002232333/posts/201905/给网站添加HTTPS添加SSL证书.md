title: 给网站添加HTTPS(添加SSL证书)
date: '2019-05-21 21:23:00'
updated: '2019-05-21 21:23:00'
tags: [Https, http]
permalink: /articles/2019/05/21/1569338007058.html
---
# 给网站添加HTTPS(添加SSSL证书)



## 一、HTTP和HTTPS的区别

[ 点击查看区别 ](https://luoshaoqi.cn/2019/05/23/httpandhttps/)



## 二、如何给你的网站添加SL证书

### 这里我以阿里云举例子，请确保你的网站已经备案并且可以访问http://你的域名



## 1.打开阿里云域名控制面板并点击管理

![管理](https://s2.ax1x.com/2019/05/23/VPgM4K.png)



## 2.点击免费申请SSL证书

![SSL](https://s2.ax1x.com/2019/05/23/VPgtHI.md.png)



## 3.点击免费证书 并填写你要颁发的域名

[![VPg6Ds.md.png](https://s2.ax1x.com/2019/05/23/VPg6Ds.md.png)](https://imgchr.com/i/VPg6Ds)



## 4.在证书面板里面找到你刚申请的证书 并根据提示完成审核然后下载SSL证书

[![VPg7r9.md.png](https://s2.ax1x.com/2019/05/23/VPg7r9.md.png)](https://imgchr.com/i/VPg7r9)



## 5.使用宝塔linux面板部署SSL证书

- 打开宝塔linux面板(如下所示)

![VPgv8O.png](https://s2.ax1x.com/2019/05/23/VPgv8O.png)

- 点击网站管理找到你之前绑定的网站如果没有绑定网站请参考本篇文档[参考](https://luoshaoqi.cn/2019/05/14/gitRepoBlog/)的添加站点部分
- 点击设置

[![VP29rd.md.png](https://s2.ax1x.com/2019/05/23/VP29rd.md.png)](https://imgchr.com/i/VP29rd)

- 在设置中的SSL一栏中如图所示添加你刚下载的证书(左边为.key文件的内容,右边为.pom文件的内容)

[![VPRDmj.png](https://s2.ax1x.com/2019/05/23/VPRDmj.png)](https://imgchr.com/i/VPRDmj)



- 点击保存即可



## 6.然后访问你的网站测试效果https://你的域名



### 最后附上我的博客链接欢迎访问

[RexRowe的博客](https://www.luoshaoqi.cn)



# END