title: 从头开始编写一个五子棋的博弈游戏(Java)(第一期)
date: '2019-06-06 22:45:00'
updated: '2019-06-06 22:45:00'
tags: [Java, 五子棋]
permalink: /articles/2019/06/06/1569338011334.html
---
# 从头开始编写一个五子棋的博弈游戏(Java)(第一期)

## 写在前面

这几天在上人工智能，老师让我们在实验环节做一个博弈类型的游戏，这里老师提示我们可以做一个五子棋的软件，于是我尝试开始自己编写一个五子棋的Java小游戏。



## 设计棋盘 

首先我们先绘制一个面板，我希望上面的功能有：开始游戏、悔棋、模式选择、认输的功能。

利用Swing设计面板代码如下：

```java
public void Init(){
  
        JFrame jf=new JFrame();
        jf.setTitle("五子棋");
        jf.setSize(650, 580);        //先设大小，再设居中;
        jf.setLocationRelativeTo(null);
        jf.setResizable(false);
        jf.setDefaultCloseOperation(3);
        jf.setLayout(new BorderLayout());
        jf.add(this);

        JPanel eastp=new JPanel();
        eastp.setPreferredSize(new Dimension(100,0));
        JButton buttonStart=new JButton("开始游戏");
        JButton buttonregret=new JButton("悔棋");
        JButton buttonlose=new JButton("认输");
        String[] itemArray = { "人人对战", "人机对战" };
        JComboBox<String> cbItem = new JComboBox<String>(itemArray);
        buttonStart.setPreferredSize(new Dimension(90,40));
        buttonregret.setPreferredSize(new Dimension(90,40));
        buttonlose.setPreferredSize(new Dimension(90,40));
        cbItem.setPreferredSize(new Dimension(90,40));
        eastp.add(buttonStart);
        eastp.add(buttonregret);
        eastp.add(buttonlose);
        eastp.add(cbItem);
        jf.add(eastp,BorderLayout.EAST);

        jf.setVisible(true);

    }
```



有了面板还不够 这里我们还需要自己绘制棋盘

这里我们采用的方法是重写Swing的paint方法这样每次程序运行是都会执行paint方法

代码如下：

```java
		// 绘制棋盘
    // 重写JPanel的paint方法
    @Override
    public void paint(Graphics g) {
        // 这里由于每次新建JPanel的时候都会调用paint方法我们这里自己重写paint方法
        super.paint(g);
        for(int i =0;i<15;i++){
            g.drawLine(30, 30 + i * 35, 30 + 35 * 14, 30 + i * 35);// 横线
            g.drawLine(30 + i * 35, 30, 30 + i * 35, 30 + 35 * 14);// 竖线
        }

    }
```



我们运行一个程序试试结果：

![](https://s2.ax1x.com/2019/06/06/VagQVP.png)

如图所示已经成功完成了面板和按钮的绘制


## 画出棋子
上一步我们已经可以画出棋盘，这里我们对paint方法扩充一下，可以这样来绘制棋子

```java
//重写重绘方法,这里重写的是第一个大的JPanel的方法
    public void paint(Graphics g) {
        super.paint(g);//画出白框

        //重绘出棋盘
        g.setColor(Color.black);
        for(int i=0;i<row;i++) {
            g.drawLine(x, y+size*i, x+size*(column-1), y+size*i);
        }
        for(int j=0;j<column;j++) {
            g.drawLine(x+size*j, y, x+size*j, y+size*(row-1));
        }

        //重绘出棋子
        for(int i=0;i<row;i++) {
            for(int j=0;j<column;j++) {
                if(isAvail[i][j]==1) {
                    int countx=size*j+20;
                    int county=size*i+20;
                    g.setColor(Color.black);
                    g.fillOval(countx-size/2, county-size/2, size, size);
                }
                else if(isAvail[i][j]==2) {
                    int countx=size*j+20;
                    int county=size*i+20;
                    g.setColor(Color.white);
                    g.fillOval(countx-size/2, county-size/2, size, size);
                }
            }
        }
    }
```