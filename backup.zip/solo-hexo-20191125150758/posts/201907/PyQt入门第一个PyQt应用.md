title: PyQt入门（第一个PyQt应用）
date: '2019-07-21 07:42:28'
updated: '2019-07-21 07:42:28'
tags: [PyQt, Python]
permalink: /articles/2019/07/21/1569338003932.html
---
# PyQt入门（第一个PyQt应用）

## 一、PyQt介绍

PyQt是一个创建GUI应用程序的工具包。它是[Python](https://baike.baidu.com/item/Python)编程语言和[Qt](https://baike.baidu.com/item/Qt)库的成功融合。Qt库是目前最强大的库之一。PyQt是由Phil Thompson 开发。

**PyQt**实现了一个Python模块集。它有超过300类，将近6000个函数和方法。它是一个多平台的工具包，可以运行在所有主要操作系统上，包括UNIX，Windows和Mac。 **PyQt**采用双许可证，开发人员可以选择GPL和商业许可。在此之前，GPL的版本只能用在Unix上，从**PyQt**的版本4开始，GPL许可证可用于所有支持的平台。

## 二、python GUI框架简介，pyqt介绍，为什么使用pyqt

#### python开发GUI程序，了解一个框架需要了解：

（1）运行效果
 （2）能够运行在哪些平台
 （3）学习成本，因为每一个GUI框架都有自己的特点
 （4）开发效率的比较，python的运行效率比c c++低，但是开发效率是比较快的

### python GUI框架:

（1）**Tkinter**: python内置的GUI框架，使用TCL实现，python中内嵌了TCL解释器，使用它的时候不用安装额外的扩展包，直接import，跨平台。不足之处在于UI布局全靠代码实现，只有15种常用部件，显示效果简陋。
 （2）**Wxpython**：用得比较广泛，跨平台，C++编写，需要安装扩展模块；文档少，遇到问题不好解决，代码布局控件，不直观。
 （3）**Pygtk**： python对GTK+GUI库的封装，在linux平台上运行的比较好，需要安装扩展模块，在windows下的兼容性有一些问题。
 （4）**pyqt**：QT原本是诺基亚的产品，源码用C++写的，python对QT的包装，跨平台，本地显示效果，根据系统决定，在win7下就是win7的显示效果；pyqt与qt的函数接口一致，qt开发问的那个丰富，所以pyqt开发文档也比较丰富；控件丰富，函数/方法多，拖曳布局；方便打包成二进制文件；GPL协议，商业程序需要购买商业版授权
 （5）**pyside**：诺基亚的亲儿子，python对QT的封装，安装扩展模块，跨平台，与pyqt的API一样，LGPL协议，新软件可以是私有的，代码布局
 （6）**Kivy**： 针对多点触控程序，智能手机平板等，也可以在没有触屏功能的系统上，全平台支持；使用python和cython（python和c语言的接口）编写；中文支持差，需要自己下载中文库并且制定路径。

### 为什么使用pyqt：

1. 因为API与qt一致，学会了pyqt再使用qt很简单
2. 文档丰富
3. 学习成本低
4. 开发迅速，qt designer拖曳布局，如果使用代码布局还需要构建全局并且调试
5. 学习经验容易迁移到pyside来开发商业应用
6. 方便打包发布软件，python本身解释语言的特点是写好的程序不编译和链接，使用文本运行解释器，边解释边执行，用户不可能装一个解释器再发源码再执行，所以打包成exe再发布

## 三、安装与配置

### 1.安装

**安装pyqt5**

```pip install pyqt5``` **or** ```pip3 install pyqt5```

**Windows安装PyQt-tools**

```pip3 install pyqt5-tools```

**Mac和Linux都不支持PyQt5-tools所以直接安装Qt Designer即可**

- Mac

  ```pip install Qt```

- Linux

  注：由于我用的Manjaro已经内置了Qt Designer，所以这里写ubuntu下的安装方法

  ```sudo apt-get install qt5-default qttools5-dev-tools```

**terminal中查看是否安装成功PyQt**

```bash
 rex@rex-linux  ~  pip list
Package              Version 
-------------------- --------
appdirs              1.4.3   
btrfsutil            1.1.1   
CacheControl         0.12.5  
chardet              3.0.4   
colorama             0.4.1   
cupshelpers          1.0     
distlib              0.2.9   
distro               1.4.0   
docopt               0.6.2   
html5lib             1.0.1   
idna                 2.8     
Jade-Application-Kit 2.0.7   
keyutils             0.5     
lockfile             0.12.2  
louis                3.10.0  
msgpack              0.6.1   
npyscreen            4.10.5  
numpy                1.16.4  
opencv-python        4.1.0.25
packaging            19.0    
pacman-mirrors       4.14.2  
pep517               0.5.0   
Pillow               6.1.0   
pip                  19.0.3  
progress             1.5     
pwquality            1.4.0   
pycairo              1.18.1  
pycups               1.9.74  
pycurl               7.43.0.2
PyGObject            3.32.2  
pyparsing            2.4.0   
PyQt5                5.13.0  
PyQt5-sip            4.19.18 
pysmbc               1.0.16  
pytoml               0.1.20  
PyYAML               5.1     
reportlab            3.5.23  
requests             2.22.0  
retrying             1.3.3   
setuptools           41.0.1  
six                  1.12.0  
team                 1.0     
udiskie              1.7.7   
urllib3              1.25.3  
webencodings         0.5.1 
```

**如图所示我们已经安装成功了PyQt5**



### 2.配置

若你已经可以在你的应用程序菜单里找到Qt Designer那就可以了

![](https://s2.ax1x.com/2019/07/20/eS1iCT.png)

**PyCharm配置**

注：PyCharm安装激活方法自行百度，这里不提供

- 打开PyCharm
- ```File```->```Setting```->```Tools```->```External Tools```

![](https://s2.ax1x.com/2019/07/20/eS1Uat.png)

- 点击加号，依次填入

  ```
  Name:Qt Designer

  Group:Qt

  Program:usr/local/designer

  Arguements:$FileName$

  Working directory:$ProjectFileDir$
  ```

![](https://s2.ax1x.com/2019/07/20/eS1wPf.png)

- 再次点击加号输入

  ```
  Name:PyUIC

  Group:Qt

  Program:/usr/bin/python3

  Arguements:-m PyQt5.uic.pyuic $FileName$ -o $FileNameWithoutExtension$.py

  Working directory:$FileDir$
  ```

![](https://s2.ax1x.com/2019/07/20/eS38YV.png)

- ```Ok```->```Apply```

**到这里PyCharm的配置基本结束**



## 四、第一个PyQt GUI应用程序

### 1.UI设计

- 打开PyCharm新建一个基于venv的python项目

- 在Setting的Project interpreter中查看是否有PyQt没有的话自行添加

![](https://s2.ax1x.com/2019/07/20/eS30T1.png)

- 打开```Tools```->```QT```->```Qt Designer```

![](https://s2.ax1x.com/2019/07/20/eS3f0A.jpg)

- 新建一个MainWindow ui界面

![](https://s2.ax1x.com/2019/07/20/eS3b6g.png)

- 向上拖拉控件并保存名为```firstMainWindow.ui```

![](https://s2.ax1x.com/2019/07/20/eS3qXQ.png)



### 2.ui文件转换为.py文件与代码编写和运行

**要想.ui文件可以被我们程序读取有两种方法**

- 使用命令行来将.ui编译为.py文件

  ```
  pyuic5 -o firstMainWindow.py firstMainWindow.ui
  ```

  编译完成后的firstMainWindow.py文件内容

```python
  from PyQt5 import QtCore, QtGui, QtWidgets
  
  
  class Ui_MainWindow(object):
      def setupUi(self, MainWindow):
          MainWindow.setObjectName("MainWindow")
          MainWindow.resize(800, 600)
          self.centralwidget = QtWidgets.QWidget(MainWindow)
          self.centralwidget.setObjectName("centralwidget")
          self.listWidget = QtWidgets.QListWidget(self.centralwidget)
          self.listWidget.setGeometry(QtCore.QRect(140, 60, 531, 371))
          self.listWidget.setObjectName("listWidget")
          MainWindow.setCentralWidget(self.centralwidget)
          self.menubar = QtWidgets.QMenuBar(MainWindow)
          self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 30))
          self.menubar.setObjectName("menubar")
          self.menuFile = QtWidgets.QMenu(self.menubar)
          self.menuFile.setObjectName("menuFile")
          self.menuEdit = QtWidgets.QMenu(self.menubar)
          self.menuEdit.setObjectName("menuEdit")
          MainWindow.setMenuBar(self.menubar)
          self.statusbar = QtWidgets.QStatusBar(MainWindow)
          self.statusbar.setObjectName("statusbar")
          MainWindow.setStatusBar(self.statusbar)
          self.actionNew = QtWidgets.QAction(MainWindow)
          self.actionNew.setObjectName("actionNew")
          self.actionOpen = QtWidgets.QAction(MainWindow)
          self.actionOpen.setObjectName("actionOpen")
          self.menuFile.addAction(self.actionNew)
          self.menuFile.addAction(self.actionOpen)
          self.menubar.addAction(self.menuFile.menuAction())
          self.menubar.addAction(self.menuEdit.menuAction())
  
          self.retranslateUi(MainWindow)
          QtCore.QMetaObject.connectSlotsByName(MainWindow)
  
      def retranslateUi(self, MainWindow):
          _translate = QtCore.QCoreApplication.translate
          MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
          self.menuFile.setTitle(_translate("MainWindow", "File"))
          self.menuEdit.setTitle(_translate("MainWindow", "Edit"))
          self.actionNew.setText(_translate("MainWindow", "New"))
          self.actionOpen.setText(_translate("MainWindow", "Open"))
  
```

- 使用代码直接读取.ui文件

  这里我们还是依旧两种方法来读取.ui文件

  1.使用我们编译好的firstMainWindow.py文件

  2.直接读取.ui文件

  - 使用firstMainWindow.py文件

    编写一个叫CallFirstMainWin.py文件,内容如下

```python
    import sys
    from PyQt5.QtWidgets import  QApplication, QMainWindow
    from firstMainWin import *
    class MyMainWindow(QMainWindow, Ui_MainWindow):
    
    
        def __init__(self, parent=None):
            super(MyMainWindow, self).__init__(parent)
            self.setupUi(self)
    
    
    if __name__ == "__main__":
        app=QApplication(sys.argv)
        myWin = MyMainWindow()
        myWin.show()
        sys.exit(app.exec_())
```

    这里我们继承了firstMainWindow.py中的Ui_MainWindow类来使用我们设计的UI

  - 直接读取.ui文件

```python
    import sys
    from PyQt5.QtWidgets import  QApplication, QMainWindow
    from firstMainWin import *
    from PyQt5.uic import loadUi
    
    app = QApplication(sys.argv)
    widget = loadUi('firstMainWin.ui')
    widget.show()
    sys.exit(app.exec_())

```

    这里是直接使用了```loadUi```方法来读取了ui文件

  **注意：为了保障界面与逻辑分离我们大部分情况下都使用第一种方法，通过继承界面文件的主窗口类来完成界面和逻辑的分离**

- 运行

  ![](https://s2.ax1x.com/2019/07/20/eStTsO.png)

两种方式都可以成功运行



## End