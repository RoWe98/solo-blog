title: 添加ssh信任，让你的登陆无需密码
date: '2019-05-29 21:23:00'
updated: '2019-05-29 21:23:00'
tags: [ssh, 公钥, 私钥]
permalink: /articles/2019/05/29/1569338008255.html
---
# 添加ssh信任，让你的登陆无需密码

## 一、生成ssh公钥和私钥

```bash
ssh-keygen -t rsa
```

在这里你会在你的.ssh文件夹里面看到两个文件

```bash
id_rsa //私钥
id_rsa.pub //公钥
```

私钥id_rsa是需要保密的，但是公钥id_rsa.pub可以用来上传到服务器的.ssh文件夹中完成配对



## 二、将你的公钥拷贝到服务器的.ssh文件夹中

### 1.利用ssh-copy-id

```bash
ssh-copy-id -i [你公钥id_rsa.pub的位置]/id_rsa.pub server_name@server_ip
```

这里会提示你输入密码 输入完成后完成公钥的上传，然后开始测试

在terminal里输入

```bash
ssh server_name@server_ip
```

如果不需要密码那么就说明已经完成了公钥的上传



### 2.使用scp命令将公钥上传到目标服务器的.ssh文件夹

在terminal中输入如下命令

```bash
scp [你公钥id_rsa.pub的位置]/id_rsa.pub server_name@server_ip:/.ssh/
```

然后进入你的服务器的.ssh文件夹如果有如下文件

```bash
id_rsa.pub
```

那么继续使用如下命令

```bash
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys 
```

这里将你的公钥id_rsa.pub 写入authorized_keys文件从而完成匹配

然后测试在本机上输入

```bash
ssh server_name@server_ip
```

如果可以进入那么恭喜你添加了ssh信任 这样就不需要密码就可以登陆了

# END