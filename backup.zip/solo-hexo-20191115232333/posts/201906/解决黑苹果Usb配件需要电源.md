title: 解决黑苹果Usb配件需要电源
date: '2019-06-14 21:15:00'
updated: '2019-06-14 21:15:00'
tags: [黑苹果]
permalink: /articles/2019/06/14/1569338011038.html
---
# 解决黑苹果Usb配件需要电源

## 问题描述

这几天在使用u盘和移动硬盘的时候突然发现会出现一个问题

如图所示：

[![](https://s2.ax1x.com/2019/06/14/V4oDGd.md.png)](https://imgchr.com/i/V4oDGd)



在远景论坛和tonymacx86上面搜寻了半天大概已经确定了问题

**USB3.0没有完美驱动成功**



## 问题解决

众所周知安装黑苹果的过程中最难的一部分不是安装而是配置驱动，这让我想着如何是好，于是我就去GitHub上找到我当时下载EFI文件 的那个仓库中 仔细阅读了他的README文档，其中在这样一个文件夹里面找到了一个文件

[Lenovo-T450-USB.kext](http://qiniusave.luoshaoqi.cn/Lenovo-T450-USB.kext.zip)

他在README里面是这么描述的

**Miscellaneous**

- A collection of different kernel extensions that I could use with this build but are currently not in use. I keep them in this folder for quick access if I find my self in a situation where I need them so that I do not have to download them all over again. The most important kext in this directory is the USB-T450-Injector.kext file. It can be used to inject the systems proper USB configuration in the absence of a properly configured USBInjectall + .aml configuration file. Don't get rid of it. If your USB ports ever stop working just load this kext into the "Other" folder and reboot.

- 意思是如果你使用USBinjectall+.aml文件有问题的话 可以用USB-T450-Injector.kext文件代替



使用方法很简单

- 打开terminal输入```diskutil list```
- 找到EFI分区 使用```sudo diskutil mount [EFI分区盘名]``` 挂载EFI分区
- 在EFI分区的CLOVER文件夹中的kext中的 Other中 删除之前的USBInjectall.kext替换为Lenovo-T450-USB.kext

- 重启计算机即可，在我重启之后发现已经解决了问题



**如图所示**

![](https://s2.ax1x.com/2019/06/14/V4T0mV.png)





![](https://s2.ax1x.com/2019/06/14/V4TR61.png)



![](https://s2.ax1x.com/2019/06/14/V4T5TO.png)



如图所示速度也是USB3.0的速度，这时候就说明了我们的USB3.0已经完美驱动了





## 解除USB端口数量限制补丁

**使用方法**

- 打开Clover Configurator 在这[下载](https://mackie100projects.altervista.org/)
- 然后点击挂载分区输入密码后选择EFI文件 如图所示

[![](https://s2.ax1x.com/2019/06/14/V47nNF.md.png)](https://imgchr.com/i/V47nNF)



[![](https://s2.ax1x.com/2019/06/14/V47GB6.md.png)](https://imgchr.com/i/V47GB6)



- 然后在内核和驱动补丁这一块点击四次加号按照名字加入如下内容

```bash
Comment: **USB** port limit patch #1 10.14.x modify by DalianSky(credit ydeng)

Name: com.apple.iokit.IO**USB**HostFamily

Find: 83FB0F0F

Replace: 83FB3F0F

MatchOS: 10.14.x



Comment: **USB** port limit patch #2 10.14.x modify by DalianSky(credit PMHeart)

Name: com.apple.iokit.IO**USB**HostFamily

Find: 83E30FD3

Replace: 83E33FD3

MatchOS: 10.14.x



Comment: **USB** Port limit patch #3 10.14.x modify by DalianSky(credits PMheart)

Name: com.apple.driver.usb.Apple**USB**XHCI

Find: 83FB0F0F

Replace: 83FB3F0F

MatchOS: 10.14.x



Comment: **USB** Port limit patch #4 10.14.x modify by DalianSky(credits PMheart)

Name: com.apple.driver.usb.Apple**USB**XHCI

Find: 83FF0F0F

Replace: 83FF3F0F

MatchOS: 10.14.x
```



- 如图所示

[![](https://s2.ax1x.com/2019/06/14/V47w3d.md.png)](https://imgchr.com/i/V47w3d)



- 然后command+s 保存关闭即可
- 重启计算机即可解决问题



# END