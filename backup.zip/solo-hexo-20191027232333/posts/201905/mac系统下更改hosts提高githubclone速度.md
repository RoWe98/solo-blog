title: mac系统下更改hosts提高github clone速度
date: '2019-05-13 21:47:12'
updated: '2019-05-13 21:47:12'
tags: [Note]
permalink: /articles/2019/05/13/1569338011970.html
---
# mac系统下更改hosts提高github clone速度

### 首先
相信很多人和我一样遇到过这种情况在github中clone项目时会发生下面这种情况

![clone](https://s2.ax1x.com/2019/05/14/Eo4r8O.jpg)

遇到这种情况大部分人肯定很难受。。。。

我clone一个项目怎么这么久！fak！

那么我们可以通过更改hosts的方法来修复这个问题


# 方法

- 在mac系统下输入如下命令

```bash
sudo vim /etc/hosts
```

如图所示：

![host](https://s2.ax1x.com/2019/05/14/Eo4DPK.jpg)

- 然后如图在最后两行加入如下命令

```bash
151.101.133.194 http://global-ssl.fastly.net
192.30.253.112 http://github.com
```

- 然后输入如下命令 刷新hosts

```bash
sudo killall -HUP mDNSResponder
```

然后测试速度大概能到500kb/s~3m/s


#END