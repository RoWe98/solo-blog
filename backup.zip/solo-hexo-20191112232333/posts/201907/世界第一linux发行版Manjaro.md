title: 世界第一linux发行版——Manjaro
date: '2019-07-19 03:19:22'
updated: '2019-07-19 03:19:22'
tags: [linux]
permalink: /articles/2019/07/19/1569338010226.html
---
# 世界第一的linux发行版 —— Manjaro

## 写在前面

也算是了却了自己的一个心事吧，之前一直想装个Arch Linux玩玩但是Arch Linux的安装实在是特别繁琐，于是在google的过程中发现了Linux发行版的排行榜，发现了Manjaro竟然已经到了全球第一的地位。[Manjaro](https://manjaro.org/)这个Linux发现版我之前也算了解过。

## 介绍

**Manjaro官方版本**
- xfce版(64)
- kde版(64)
- gnome版(64)
- Architect版
- Arm版
- 32位版(xfce)
- 社区版(deepin桌面版,等等)

这些版本你在[Manjaro的官方网站](https://manjaro.org/)的下载页面可以查看到具体的区别

![](https://s2.ax1x.com/2019/07/18/ZjVFSK.png)


## 安装

**1.下载镜像**

[Manjaro下载地址](https://manjaro.org/get-manjaro/)

**2.刻录镜像**

这里我使用的是[refus](https://rufus.ie/)这个刻录软件
![](https://s2.ax1x.com/2019/07/18/ZjV1l8.png)

**这里是截取的官方的图所以显示ubuntu不要纠结**
**如果弹窗提示请选择dd**

**3.安装**

这里简单说说基本就是这几个步骤

- u盘启动
- 选择安装
- 重启

## 系统配置

先给大家看看我安装之后的样子

![](https://s2.ax1x.com/2019/07/18/ZjVWfx.png)

**先排列源**
```bash
sudo pacman-mirrors -g
```
**同步并优化（类似磁盘整理，固态硬盘无需操作）**
```sudo pacman-optimize && sync```
**升级系统**
```sudo pacman -Syyu```
**添加中科大源**
打开配置文件在文件末尾添加
```bash
sudo nano /etc/pacman.conf
[archlinuxcn]
SigLevel = Optional TrustedOnly
Server = https://mirrors.ustc.edu.cn/archlinuxcn/$arch
```

**导入GPG Key**
```sudo pacman -Syy && sudo pacman -S archlinuxcn-keyring```
现在可以安装软件了，比如 chrome 和搜狗拼音输入法

**安装搜狗输入法**
```bash
sudo pacman -S fcitx-sogoupinyin
sudo pacman -S fcitx-im
sudo pacman -S fcitx-configtool # 图形化的配置工具
```

**需要修改配置文件 ~/.xprofile
添加如下语句**

```bash
export GTK_IM_MODULE=fcitx
export QT_IM_MODULE=fcitx
export XMODIFIERS="@im=fcitx"
```

**安装包管理工具yaourt**
```pacman -S yaourt```

这个管理工具可以帮助你安装aur源上的程序

通过这个工具你可以安装deepin打包的各种软件，例如:
- 微信
- QQ
- 百度网盘
- 等等

通过下面的语句安装
```
yaourt -S deepin-wine-qq
yaourt -S deepin-wine-pan
yaourt -S deepin-wine-wechat
```
![](https://s2.ax1x.com/2019/07/18/Zje0LF.png)

安装的话就是输入对应的你想安装的程序前的序号即可

**修复kde桌面运行deepin-wine程序闪退的错误**

在非gnome桌面环境下，Deepin-Wine软件大部分不能启动，例如deepin-Tim，deepin-QQ以及微信等。按照DLM的说法，深度在打包Deepin-Wine软件时加入了对Gnome的依赖。通过安装```gnome-settings-daemon```即可解决。

1.安装gnome-settings-daemon
```sudo apt install gnome-settings-daemon```

2.复制org.gnome.SettingsDaemon.XSettings.desktop
```cp /etc/xdg/autostart/org.gnome.SettingsDaemon.XSettings.desktop ~/.config/autostart```

3.设置org.gnome.SettingsDaemon.XSettings.desktop开机自启

在KDE中的一个简单的配置方法是：打开```系统设置```->```开机和关机```->```自动启动```->```设置为已启用```->```最后注销登录```或者```重启电脑```即可打开Deepin-Wine软件。（其他非KDE桌面环境，方法自己参考）

![](https://s2.ax1x.com/2019/07/18/ZjebWt.png)

**记得选择**高级中的如下选项

![](https://s2.ax1x.com/2019/07/18/ZjmCYn.png)

然后你就可以正常运行deepin打包的wine软件了

## 其他

**常用软件安装**
```
谷歌浏览器
pacman -S google-chrome
国内版火狐浏览器
pacman -S firefox firefox-i18n-zh-cn
压缩解压缩
pacman -S file-roller unrar unzip p7zip
Git ssh
pacman -S git openssh
安装wps
yaourt -S wps-office
VSCode
pacman -S visual-studio-code-bin 
```
**pacman和yaourt常用命令**
```
安装 pacman -S
删除 pacman -R
移除已安装不需要软件包 pacman -Rs
删除一个包,所有依赖 pacman -Rsc
升级包 pacman -Syu
查询包数据库 pacman -Ss
搜索以安装的包 pacman -Qs
显示包大量信息 pacman -Si
本地安装包 pacman -Qi
清理包缓存 pacman -Sc 
```

## End