title: 我在 GitHub 上的开源项目
date: '2019-10-06 23:13:32'
updated: '2019-10-06 23:13:32'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [GraduateEntranceExam](https://github.com/RoWe98/GraduateEntranceExam) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/RoWe98/GraduateEntranceExam/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/RoWe98/GraduateEntranceExam/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RoWe98/GraduateEntranceExam/network/members "分叉数")</span>

This repository including my Graduate Entrance Exam review file abour data structure and operating system



---

### 2. [PythonCode](https://github.com/RoWe98/PythonCode) <kbd title="主要编程语言">QML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RoWe98/PythonCode/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/RoWe98/PythonCode/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RoWe98/PythonCode/network/members "分叉数")</span>

平常拿python写的代码和一些小工具



---

### 3. [Zoomer](https://github.com/RoWe98/Zoomer) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RoWe98/Zoomer/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/RoWe98/Zoomer/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RoWe98/Zoomer/network/members "分叉数")</span>

Zoomer is an open source face recognition lib



---

### 4. [RoWe98.github.io](https://github.com/RoWe98/RoWe98.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RoWe98/RoWe98.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/RoWe98/RoWe98.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RoWe98/RoWe98.github.io/network/members "分叉数")</span>





---

### 5. [JavaCode](https://github.com/RoWe98/JavaCode) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RoWe98/JavaCode/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/RoWe98/JavaCode/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RoWe98/JavaCode/network/members "分叉数")</span>

JavaCode



---

### 6. [WisdomClassRaspberry](https://github.com/RoWe98/WisdomClassRaspberry) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RoWe98/WisdomClassRaspberry/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/RoWe98/WisdomClassRaspberry/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RoWe98/WisdomClassRaspberry/network/members "分叉数")</span>

智慧教室树莓派端



---

### 7. [Wisdom_Classroom_RecoPi](https://github.com/RoWe98/Wisdom_Classroom_RecoPi) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RoWe98/Wisdom_Classroom_RecoPi/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/RoWe98/Wisdom_Classroom_RecoPi/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RoWe98/Wisdom_Classroom_RecoPi/network/members "分叉数")</span>

智慧教室识别树莓派端



---

### 8. [solo-blog](https://github.com/RoWe98/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/RoWe98/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RoWe98/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RoWe98/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://blog.luoshaoqi.cn`](https://blog.luoshaoqi.cn "项目主页")</span>

Rex's Blog - 起风了，唯有努力生存



---

### 9. [AspdotNetProject](https://github.com/RoWe98/AspdotNetProject) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/RoWe98/AspdotNetProject/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RoWe98/AspdotNetProject/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/RoWe98/AspdotNetProject/network/members "分叉数")</span>

Includes My DotNet Projects



---

### 10. [FaceSign](https://github.com/RoWe98/FaceSign) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RoWe98/FaceSign/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RoWe98/FaceSign/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RoWe98/FaceSign/network/members "分叉数")</span>

基于人脸识别技术的智能人脸签到系统

