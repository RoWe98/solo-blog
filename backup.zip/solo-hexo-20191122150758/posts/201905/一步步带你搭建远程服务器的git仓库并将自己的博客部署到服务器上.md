title: 一步步带你搭建远程服务器的git仓库,并将自己的博客部署到服务器上
date: '2019-05-15 00:16:39'
updated: '2019-05-15 00:16:39'
tags: [git仓库, 博客搭建, 宝塔面板]
permalink: /articles/2019/05/15/1569338007569.html
---
# 一步步带你搭建远程服务器的git仓库,并将自己的博客部署到服务器上

#### 本次教程基于宝塔linux控制面板 没有安装宝塔的可以进入如下网页安装宝塔

#### 本次教程基于HEXO博客架构 这里我默认你已经安装了hexo博客而且可以往github上push页面 并且可以访问 
http://你的githubid.github.io 的博客网站

#### 如果你已经测试成功上面的两个步骤那你就可以继续往下看 如果不行 请将上面两个前提条件实现

- [宝塔安装](https://www.bt.cn/bbs/thread-19376-1-1.html)

使用阿里云的朋友如果你的服务器为新的镜像请做如下操作：

- 将你的系统镜像更改为宝塔面板(BT-PANEL)

- 在防火墙端口开放如下端口：8888，80，3306，8080

- http://服务器ip:8888 为你的宝塔控制面板地址

- 输入如下命令查看宝塔的默认密码，ps：默认管理员账号为:admin

```bash
sudo cat /www/server/panel/default.pl
```

### 看到这一步我已经默认你安装完宝塔linux界面并可以进入管理员界面 如图所示

![界面](https://s2.ax1x.com/2019/05/14/EohDXj.md.jpg)


#### 服务器设置

#### 这里我默认认为你已经在本地配置了git账号密码

# 1.安装git

当然以下操作都是在你远程服务器上操作的

- [git教程](https://www.liaoxuefeng.com/wiki/896043488029600)

centos 输入以下命令

```bash
git --version // 如无，则安装
yum install curl-devel expat-devel gettext-devel openssl-devel zlib-devel perl-devel
yum install -y git
```

# 2.配置git仓库
1.创建用户git并配置仓库
```bash
useradd git
passwd git // 设置密码
su git // 这步很重要，不切换用户后面会很麻烦
mkdir -p /www/wwwroot/blog // 项目存在的真实目录,由于需要用到宝塔 我们把博客地址放到宝塔网站地址下
```

##### 如果上面mkdir出错是因为我们没有把git用户添加到sudoers中

##### 做如下操作

```bash
sudo su //输入密码进入root用户
cd /etc/
vim sudoers
```
找到root ALL=(ALL)   ALL
在下面添加
```bash
git ALL=(ALL)   ALL
```
注意对齐


然后进入git用户执行如下命令
```bash
su git
sudo mkdir -p /www/wwwroot/blog
cd /home/git/
mkdir repos && cd repos
git init --bare blog.git
cd blog.git/hooks
vi post-receive // 创建hook钩子函数，输入了内容如下（原理可以参考上面的链接)
```
输入如下内容
```bash
#!/bin/sh
git --work-tree=/www/wwwroot/blog --git-dir=/home/git/repos/blog.git checkout -f
```

添加完毕后修改权限，执行如下命令
```bash
chmod +x post-receive
exit // 退出到 root 登录
chown -R git:git /home/git/repos/blog.git // 添加权限
```

测试git仓库是否可用，另找空白文件夹，执行如下命令
注意这一步在自己的电脑上测试

```bash
git clone git@server_ip:/home/git/repos/blog.git
```
如果能把空仓库拉下来，就说明 git 仓库搭建成功了
当然你会提示你拉下来的是空仓库

# 3.本地电脑设置

建立ssh信任关系，在本地电脑，执行如下命令

参考资料：

- [ssh-copy-id 建立信任](http://roclinux.cn/?p=2551)
- mac系统自己百度(google)安装ssh-copy-id 其实就是一个简单的脚本

```bash
ssh-copy-id -i C:/Users/yourname/.ssh/id_rsa.pub git@server_ip
ssh git@server_ip // 测试能否登录
```
##### 注：此时的 ssh 登录 git 用户不需要密码！否则就有错，请仔细重复步骤 3-4

如果第 5 步能成功，为了安全起见禁用git用户的 shell 登录权限，从而只能用git clone,git push等登录，执行如下命令

```bash
cat /etc/shells // 查看`git-shell`是否在登录方式里面，有则跳过
which git-shell // 查看是否安装
vi /etc/shells
添加上2步显示出来的路劲，通常在 /usr/bin/git-shell
```

修改/etc/passwd中的权限，将原来的
```bash
git:x:1000:1000::/home/git:/bin/bash
```
修改为
```bash
git:x:1000:1000:,,,:/home/git:/usr/bin/git-shell
```

# 4.宝塔面板设置

- 进入你的宝塔面板 yourip:8888 并输入账号密码进入如下界面

![界面](https://s2.ax1x.com/2019/05/14/Eoh5jJ.jpg)

选择网站 添加站点 如图所示

![网站](https://s2.ax1x.com/2019/05/14/Eohf9U.jpg)

然后填入如下信息

- 网站ip
- 网站目录选择/www/wwwroot/blog

![设置](https://s2.ax1x.com/2019/05/14/Eoh4c4.jpg)

然后点击提交

# 5.HEXO配置文件设置

在你和hexo博客配置文件中找到根目录中的_config.yml 在deploy项中修改如下


![设置](https://s2.ax1x.com/2019/05/14/Eohh3F.jpg)

```bash
deploy:
    type: git
    repository:
      github: 这里是你的github.io页面地址
      server: git@你的ip:/home/git/repos/blog.git
    branch: master
```

然后执行如下命令将你的博客push到服务器的git仓库中
```bash
hexo clean
hexo d -g
```

然后在浏览器输入你的网站http://ip/ 查看效果

成功的话会显示你的主页界面

![主页](https://s2.ax1x.com/2019/05/14/EohRhT.jpg)

最后放上我的博客首页欢迎访问

- [我的博客](https://www.luoshaoqi.cn/)

#END