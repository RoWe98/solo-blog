title: 人脸识别算法(Python)
date: '2019-06-18 23:26:39'
updated: '2019-06-18 23:26:39'
tags: [人脸识别, 机器学习]
permalink: /articles/2019/06/18/1569338000830.html
---
# 人脸识别算法(Python)

## 写在前面

**学习OpenCV 很久了，正好这段时间在学习机器学习，课程刚好讲到人脸识别**

课程连接如下

[TensorFlow快速入门与实战](https://www.bilibili.com/video/av54618101)

在其中的一课中讲到了OpenCV的人脸识别算法



**人脸识别的方法不止有OpenCV调用自带的训练样本集，本文提到的方法有两种**

- OpenCV人脸识别
- face-recognition库



## 算法介绍(OpenCV)

**这里使用到了OpenCV的一个人脸训练样本集,点击下面的超链接即可下载**

[haarcascade_frontalface_default.xml](http://qiniusave.luoshaoqi.cn/haarcascade_frontalface_default.xml)

这个训练集是OpenCV为我们提供的已经通过机器学习训练好的一个样本集，当然你也可以去OpenCV的GitHub主页去查看其它的训练样本集

[OpenCV](https://github.com/opencv/opencv)

为了方便日后学习，本人还是建议大家将项目clone下载可以日后查看代码。



## OpenCV人脸识别算法逻辑

- 读取图片
- 读取样本集
- 调用OpenCV识别人脸
- 使用rectangle方法绘制人脸



## 代码实现(OpenCV)

```python
# -*- coding: utf-8 -*-

import cv2
import sys

# Get user supplied values
imagePath = sys.argv[1]
cascPath = "haarcascade_frontalface_default.xml"

# Create the haar cascade
faceCascade = cv2.CascadeClassifier(cascPath)

# Read the image
image = cv2.imread(imagePath)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Detect faces in image
faces = faceCascade.detectMultiScale(
    gray,
    scaleFactor=1.1,
    minNeighbors=5,
    minSize=(30, 30)
)

print("Found {0} Faces! in the Picture".format(len(faces)))

# Draw a rectangle around the faces
for(x, y, w, h) in faces:
    cv2.rectangle(image, (x,y), (x+w,y+w), (0, 255, 0), 2)

cv2.imshow("Faces found", cv2.resize(image,(1024,768)))
cv2.waitKey(0)
```



## 输出情况

### 处理输出情况

[![](https://s2.ax1x.com/2019/06/18/VqyHJJ.md.png)](https://imgchr.com/i/VqyHJJ)



### 终端输出情况

```bash
rex@RexMacBookPro:PythonCode/FaceDetect ‹master*›$ python3 FaceDetect_Front.py /Users/rex/Desktop/乱七八糟图片/test2.jpg
Found 7 Faces! in the Picture
```





## 算法介绍(face-recognition库)



**face_recognition使用世界上最简单的人脸识别工具，在Python或命令行中识别和操作人脸。使用dlib最先进的人脸识别技术构建而成，并具有深度学习功能。 该模型在[Labeled Faces in the Wild](http://vis-www.cs.umass.edu/lfw/)基准中的准确率为99.38％。**

### face_recognition安装

- ```pip3 install face_recognition```

**注意！安装之前请安装make** ```

- Ubuntu ```sudo apt-get install make```
- Centos ```sudo yum install make```
- MaxOS X ```sudo brew install make```

**安装完成之后打开Python终端输入**```import face_recognition```

![](https://s2.ax1x.com/2019/06/18/VqgVIS.png)

若没有报错则说明安装face_recognition成功

**face_recognition学习**

[face_recognition](https://www.baidu.com/link?url=k6yEWlP9U9nd8eCASeJFSrSVl6nYvy4vKj473sNkADEYcuv3i6o-hqM46Kadi-FR&wd=&eqid=c7a1224f000387c3000000065d088dec)



## face_recognition库人脸识别算逻辑

- 读取图片
- 使用face_recognition读取图片
- 调用face_recognition的face_locations方法定位人脸
- 调用OpenCV的rectangle方法绘制人脸框
- 显示处理结果



## 代码实现(face_recognition库)

```python

import cv2
import sys

import face_recognition

# Get user supplied values
imagePath = sys.argv[1]

# Load the image from face_recognition
image = face_recognition.load_image_file(imagePath)

# Detect faces in image

face_loaction = face_recognition.face_locations(image)

print("Found {0} Faces!".format(len(face_loaction)))

# Read the image with openCV

image = cv2.imread(imagePath)

# Draw a rectangle around the faces
for(top, right, bottom, left) in face_loaction:
    cv2.rectangle(image, (left, top), (right, bottom), (0, 255, 0), 2)

cv2.imshow("Faces found", cv2.resize(image,(1024,768)))
cv2.waitKey(0)
```



## 输出情况

### 处理输出情况

[![](https://s2.ax1x.com/2019/06/18/Vq4mGT.md.png)](https://imgchr.com/i/Vq4mGT)



### 终端输出情况

```bash
rex@RexMacBookPro:PythonCode/FaceDetect ‹master*›$ python3 FaceDetect_face_recognition.py /Users/rex/Desktop/乱七八糟图片/test2.jpg 
Found 7 Faces!
```



## End