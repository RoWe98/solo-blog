title: 从头开始编写一个五子棋的博弈游戏(Java)(第二期)
date: '2019-06-15 08:26:00'
updated: '2019-06-15 08:26:00'
tags: [Java, 五子棋]
permalink: /articles/2019/06/15/1569338002848.html
---
# 从头开始编写一个五子棋的博弈游戏(Java)(第二期)

## 回顾

**[上一期]([https://www.luoshaoqi.cn/2019/06/06/%E4%BA%94%E5%AD%90%E6%A3%8B%E4%B8%80/](https://www.luoshaoqi.cn/2019/06/06/五子棋一/))**已经可以成功实现一个棋盘了 这一期我们主要来编写键盘的监听方法和其他工具类



## 按钮监听

如上期所示我们在我们键盘的右边新增了几个按钮 接下来我自己又对按钮进行了一些更改如下所示：

[![](https://s2.ax1x.com/2019/06/15/V5vPDH.md.png)](https://imgchr.com/i/V5vPDH)



在上期的基础上我自己重新 更改了一些按钮 添加了作者信息显示 游戏说明的按钮

### 实现方式

键盘的监听实现起来很简单，方法如下：

- 实例化一个ActionEvent 对象来管理按键
- 通过e.getActionCommand()来判断按下了哪个按钮
- 分别实现新游戏、放弃、说明等功能

**部分代码如下:**

```java

public void actionPerformed(ActionEvent e) {

        //必须得用else if，因为如果没有else if你每次在右边的界面点击时它都会获取人人对战或者人机对战的					信息，每次都会重置棋盘数组
        //获取当前被点击按钮的内容，判断是不是"开始新游戏"这个按钮
        if(e.getActionCommand().equals("新游戏")) {
            //重绘棋盘
            for(int i=0;i<gf.isAvail.length;i++)
                for(int j=0;j<gf.isAvail[i].length;j++)
                    gf.isAvail[i][j]=0;
            gf.repaint();
            //如果是开始新游戏的按钮，再为左半部分设置监听方法
            gf.turn=1;
        }
  			 // forkme github关注
        else if(e.getActionCommand().equals("我的github")){
            if(java.awt.Desktop.isDesktopSupported()){
                try {
                    //创建一个URI实例
                    java.net.URI uri = java.net.URI.create("https://github.com/RoWe98");
                    //获取当前系统桌面扩展
                    java.awt.Desktop dp = java.awt.Desktop.getDesktop();
                    //判断系统桌面是否支持要执行的功能
                    if(dp.isSupported(java.awt.Desktop.Action.BROWSE)){
                    //获取系统默认浏览器打开链接
                        dp.browse(uri);
                    }
                } catch (java.io.IOException error) {
                //此为无法获取系统默认浏览器
                    error.printStackTrace();
                }
            }
        }

        // 按下readme 游戏说明
        else if(e.getActionCommand().equals("说明")){
            String readme = "1.选择一个游戏模式：人人或人机"+"\n" +
                "2.开始新游戏"+"\n"+"3.Enjoy!";
            JOptionPane.showMessageDialog(null,readme);
        }

        else if(e.getActionCommand().equals("放弃")) {
            if(gf.turn==1) {
                JOptionPane.showMessageDialog(null, "白方胜");
                System.out.println("白方胜!");
            }else JOptionPane.showMessageDialog(null, "黑方胜");
            //重新把棋盘设置为不可操作
            gf.turn=0;
        }
        else if(box.getSelectedItem().equals("人机")) {
            gf.ChooseType=1;
            gf.turn=0;
        }
        else if(box.getSelectedItem().equals("人人")){
            gf.ChooseType=0;
            gf.turn=0;
        }
    }
```



## 棋盘信息以及棋子信息存储以及设定

### 棋子坐标信息

**首先我们来思考一个问题：如何存储当前棋子在棋盘上的坐标？**

答：建立一个Bean来存储当前棋子的坐标信息

我相信大部分人都会这么想，当然我们这里也是可以这么实现这个功能的

如下所示，我们建立一个类来存放我们棋子的坐标

```java
//新建一个棋子类ChessPosition保存每一步棋子所在的位置
public class ChessPosition {
    public int Listi,Listj;

    public ChessPosition() {

    }
    public ChessPosition(int Listi,int Listj) {
        this.Listi=Listi;
        this.Listj=Listj;
    }
}

```

通过这个类 就可以让我们来保存每一步棋子的位置 信息



### 棋盘信息设定

同样的问题，我们如何设定棋盘的信息 比如棋盘大小为15*15 ，格子大小，棋盘的起点坐标

这里我们可以使用Java中一个特别好用的东西，那就是接口，我们完全可以定义一个接口保存我们定义的信息，在之后的类中调用我们棋盘信息的时候只需要implement接口即可

接口定义如下所示：

```java
//定义与棋盘数据相关的接口，保存棋盘的起点，格子大小，行数列数等信息
public interface GoBangconfig {
    int x=20,y=20,size=40,row=15,column=15;
}
```

**如图我们已经设置了按键监听所以我们在主方法中为按钮添加监听**
```java
//按钮监控类
ButtonListener butListen=new ButtonListener(this,box);
//对每一个按钮都添加状态事件的监听处理机制
for(int i=0;i<butname.length;i++) {
    button[i].addActionListener(butListen);//添加发生操作的监听方法
    }

    //对可选框添加事件监听机制
    box.addActionListener(butListen);

    FrameListener fl=new FrameListener();
    fl.setGraphics(this);//获取画笔对象
    this.addMouseListener(fl);
```

**本期主要写按钮监听和棋盘棋子设定**


## End